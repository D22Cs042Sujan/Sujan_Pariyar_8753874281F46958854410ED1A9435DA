def is_leap_year(year):
    return (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0)

def get_user_input():
    while True:
        try:
            year = int(input("Enter a year: "))
            return year
        except ValueError:
            print("Invalid input. Please enter a valid year.")

def print_leap_year_result(year):
    result = "is" if is_leap_year(year) else "is not"
    print(f"{year} {result} a leap year.")

def main():
    year = get_user_input()
    print_leap_year_result(year)

if __name__ == "__main__":
    main()
