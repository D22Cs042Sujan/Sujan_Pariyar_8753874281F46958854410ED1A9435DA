def factorial(n):
    if n < 0:
        raise ValueError("Factorial is not defined for negative numbers.")
    return 1 if n == 0 else n * factorial(n - 1)

def main():
    try:
        num = int(input("Enter a Integer: "))
        result = factorial(num)
        print(f"The factorial of {num} is {result}")
    except ValueError:
        print("Invalid input. Please enter a valid non-negative integer.")
    except RecursionError:
        print("Factorial calculation failed due to a large input value.")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()
